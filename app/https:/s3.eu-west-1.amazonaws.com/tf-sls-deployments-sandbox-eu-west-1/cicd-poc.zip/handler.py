import json

def main(event, context):
    msg = "Yo poto! (v.0.0.4)"
    return msg

